<template>
  <div class="post">
    <div class="rectangle-2">
      <p class="post-text">{{ post.title }}</p>
      <div class="line-3"></div>
      
      <div class="post-actions">
        <button @click="openEditModal" class="btn-edit">Изменить</button>
        <button @click="toggleComments" class="btn-comments">
          {{ showComments ? 'Спрятать' : 'Комментарии' }}
        </button>
        <button @click="deletePost" class="btn-delete">Удалить</button>
        <span class="comment-count">Количество комментарий - {{ post.comments.length }}</span>
      </div>

      <div v-if="showComments" class="comments-section">
        <div class="add-comment-section">
          <input
            v-model="newComment"
            @keyup.enter="addComment"
            type="text"
            placeholder="Новый комментарий ..."
            class="comment-input"
          />
          <button @click="addComment" class="btn-add-comment">Добавить</button>
        </div>

        <div class="comments-list">
          <CommentItem
            v-for="comment in post.comments"
            :key="comment.id"
            :comment="comment"
            @delete-comment="() => handleDeleteComment(comment.id)"
          />
        </div>

        <button @click="toggleComments" class="btn-hide">Спрятать</button>
      </div>
    </div>

    <!-- Modal for editing post -->
    <div v-if="isModalOpen" class="modal-area" @click.self="closeModal">
      <div class="modal">
        <div class="rectangle-2 modal-rectangle">
          <textarea
            v-model="editText"
            class="modal-textarea"
          ></textarea>
          <div class="modal-actions">
            <button @click="saveChanges" class="btn-confirm">Подтвердить</button>
            <button @click="closeModal" class="btn-close-modal">Закрыть</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import CommentItem from './CommentItem.vue'

const props = defineProps({
  post: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['update-post', 'delete-post', 'add-comment', 'delete-comment'])

const showComments = ref(false)
const isModalOpen = ref(false)
const editText = ref(props.post.title)
const newComment = ref('')

const toggleComments = () => {
  showComments.value = !showComments.value
}

const openEditModal = () => {
  editText.value = props.post.title
  isModalOpen.value = true
}

const closeModal = () => {
  isModalOpen.value = false
  editText.value = props.post.title
}

const saveChanges = () => {
  if (editText.value.trim() && editText.value !== props.post.title) {
    emit('update-post', props.post.id, editText.value)
  }
  closeModal()
}

const deletePost = () => {
  if (confirm('Вы уверены, что хотите удалить этот пост?')) {
    emit('delete-post', props.post.id)
  }
}

const addComment = () => {
  if (newComment.value.trim()) {
    emit('add-comment', props.post.id, newComment.value)
    newComment.value = ''
  }
}

const handleDeleteComment = (commentId) => {
  if (confirm('Удалить комментарий?')) {
    emit('delete-comment', props.post.id, commentId)
  }
}
</script>

<style scoped>
.post {
  position: relative;
  width: 800px;
  margin: 0 auto 30px;
}

.rectangle-2 {
  box-sizing: border-box;
  position: relative;
  width: 800px;
  background: #FCFBFB;
  border: 2px solid #0094FF;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 15px;
  padding: 16px 20px;
}

.post-text {
  width: 752px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 24px;
  line-height: 29px;
  color: #000000;
  margin-bottom: 16px;
}

.line-3 {
  width: 750px;
  height: 0px;
  border: 1px solid #9C9C9C;
  margin: 16px 0;
}

.post-actions {
  position: relative;
  display: flex;
  gap: 10px;
  align-items: center;
  margin-top: 16px;
}

.btn-edit {
  width: 121px;
  height: 43px;
  background: #216CFF;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

.btn-comments {
  width: 156px;
  height: 43px;
  background: #216CFF;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

.btn-delete {
  width: 121px;
  height: 43px;
  background: #FF218B;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

.comment-count {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #000000;
  margin-left: auto;
}

.comments-section {
  margin-top: 20px;
  border-top: 1px solid #9C9C9C;
  padding-top: 20px;
}

.add-comment-section {
  position: relative;
  margin-bottom: 20px;
}

.comment-input {
  box-sizing: border-box;
  width: 100%;
  height: 43px;
  background: #FFFFFF;
  border: 1px solid #6E6E6E;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #000000;
  padding: 0 16px;
}

.comment-input:focus {
  outline: none;
  border-color: #0094FF;
}

.btn-add-comment {
  position: absolute;
  right: 0;
  top: 0;
  width: 117px;
  height: 43px;
  background: #216CFF;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

.comments-list {
  margin-bottom: 16px;
}

.btn-hide {
  width: 115px;
  height: 43px;
  background: #216CFF;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

/* Modal styles */
.modal-area {
  position: fixed;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  background: rgba(108, 158, 255, 0.59);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal {
  position: relative;
  width: 800px;
}

.modal-rectangle {
  padding: 20px;
}

.modal-textarea {
  box-sizing: border-box;
  width: 100%;
  height: 113px;
  background: #FFFFFF;
  border: 1px solid #6E6E6E;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 24px;
  line-height: 29px;
  color: #000000;
  padding: 16px;
  resize: vertical;
  margin-bottom: 20px;
}

.modal-textarea:focus {
  outline: none;
  border-color: #0094FF;
}

.modal-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.btn-confirm {
  width: 148.67px;
  height: 43px;
  background: #216CFF;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

.btn-close-modal {
  width: 121px;
  height: 43px;
  background: #FF218B;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

button:hover {
  transform: translateY(-2px);
  transition: transform 0.2s;
}

button:active {
  transform: translateY(0);
}
</style>
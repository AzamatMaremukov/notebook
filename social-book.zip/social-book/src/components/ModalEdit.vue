<template>
  <div class="modal">
    <div class="content">
      <textarea v-model="text"></textarea>
      <button @click="save">Сохранить</button>
      <button @click="$emit('close')">Закрыть</button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { usePostStore } from '../stores/posts'

const props = defineProps(['post'])
const store = usePostStore()

const text = ref(props.post.title)

const save = () => {
  store.updatePost(props.post.id, text.value)
  emit('close')
}
</script>

<style>
.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
}
.content {
  background: white;
  padding: 20px;
  margin: 100px auto;
  width: 300px;
}
</style>

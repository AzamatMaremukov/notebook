<template>
  <div class="create-post-form">
    <div class="rectangle-2">
      <textarea 
        v-model="postContent" 
        class="post-textarea"
        placeholder="Новый пост ..."
      ></textarea>
      <button @click="createPost" class="btn-add">Добавить</button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const emit = defineEmits(['create-post'])
const postContent = ref('')

const createPost = () => {
  if (postContent.value.trim()) {
    emit('create-post', postContent.value)
    postContent.value = ''
  }
}
</script>

<style scoped>
.create-post-form {
  position: relative;
  width: 800px;
  margin: 0 auto;
}

.rectangle-2 {
  box-sizing: border-box;
  position: relative;
  width: 800px;
  background: #FCFBFB;
  border: 2px solid #0094FF;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 15px;
  padding: 20px;
}

.post-textarea {
  width: 100%;
  height: 104px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 24px;
  line-height: 29px;
  color: #000000;
  background: #FFFFFF;
  border: 1px solid #6E6E6E;
  border-radius: 15px;
  padding: 16px;
  resize: vertical;
  margin-bottom: 20px;
}

.post-textarea:focus {
  outline: none;
  border-color: #0094FF;
}

.btn-add {
  position: absolute;
  right: 20px;
  bottom: 20px;
  width: 121px;
  height: 43px;
  background: #216CFF;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
  transition: transform 0.2s;
}

.btn-add:hover {
  transform: translateY(-2px);
  background: #0056b3;
}
</style>
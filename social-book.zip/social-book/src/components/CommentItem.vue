<template>
  <div class="comment-item">
    <div class="rectangle-6">
      <p class="comment-text">{{ comment.text }}</p>
    </div>
    <button @click="deleteComment" class="btn-delete-comment">Удалить</button>
  </div>
</template>

<script setup>
const props = defineProps({
  comment: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['delete-comment'])

const deleteComment = () => {
  emit('delete-comment')
}
</script>

<style scoped>
.comment-item {
  position: relative;
  width: 751px;
  height: 43px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 20px;
}

.rectangle-6 {
  box-sizing: border-box;
  width: 624px;
  height: 43px;
  background: #FCFBFB;
  border: 2px solid #0094FF;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 15px;
  display: flex;
  align-items: center;
  padding: 0 16px;
}

.comment-text {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #000000;
  margin: 0;
}

.btn-delete-comment {
  width: 107px;
  height: 43px;
  background: #FF218B;
  border-radius: 15px;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 20px;
  color: #FCFBFB;
  border: none;
  cursor: pointer;
}

.btn-delete-comment:hover {
  transform: translateY(-2px);
  transition: transform 0.2s;
}
</style>
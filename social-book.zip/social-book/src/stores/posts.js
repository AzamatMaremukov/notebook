import { defineStore } from 'pinia'

export const usePostsStore = defineStore('posts', {
  state: () => ({
    posts: [
      {
        id: 1,
        title: "Сегодня было замечательное предложение пойти поужинать этим вечером. Главное, чтобы погода была преимущественно теплой.",
        comments: [
          { id: 1, text: "Самый яркий комментарий в этом посте" },
          { id: 2, text: "Один из бессмысленный комментарий в этом посте" }
        ]
      },
      {
        id: 2,
        title: "Краткосрочное вымышленное преломление может выполнять особую роль в пространстве главной роли игрока",
        comments: [
          { id: 1, text: "Очень научно и непонятно" }
        ]
      }
    ]
  }),

  actions: {
    addPost(title) {
      const newPost = {
        id: Date.now(),
        title,
        comments: []
      }
      this.posts.push(newPost)
    },

    deletePost(postId) {
      const index = this.posts.findIndex(post => post.id === postId)
      if (index !== -1) {
        this.posts.splice(index, 1)
      }
    },

    updatePost(postId, newTitle) {
      const post = this.posts.find(post => post.id === postId)
      if (post) {
        post.title = newTitle
      }
    },

    addComment(postId, commentText) {
      const post = this.posts.find(post => post.id === postId)
      if (post) {
        const newComment = {
          id: Date.now(),
          text: commentText
        }
        post.comments.push(newComment)
      }
    },

    deleteComment(postId, commentId) {
      const post = this.posts.find(post => post.id === postId)
      if (post) {
        const index = post.comments.findIndex(comment => comment.id === commentId)
        if (index !== -1) {
          post.comments.splice(index, 1)
        }
      }
    }
  }
})
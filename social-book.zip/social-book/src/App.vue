<template>
  <div class="app">
    <div class="container">
      <div class="create-post-section">
        <CreatePostForm @create-post="handleCreatePost" />
      </div>

      <div class="posts-list">
        <PostCard
          v-for="post in postsStore.posts"
          :key="post.id"
          :post="post"
          @update-post="handleUpdatePost"
          @delete-post="handleDeletePost"
          @add-comment="handleAddComment"
          @delete-comment="handleDeleteComment"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { usePostsStore } from './stores/posts'
import CreatePostForm from './components/CreatePostForm.vue'
import PostCard from './components/PostCard.vue'

const postsStore = usePostsStore()

const handleCreatePost = (title) => {
  if (title.trim()) {
    postsStore.addPost(title)
  }
}

const handleUpdatePost = (postId, newTitle) => {
  if (newTitle.trim()) {
    postsStore.updatePost(postId, newTitle)
  }
}

const handleDeletePost = (postId) => {
  postsStore.deletePost(postId)
}

const handleAddComment = (postId, commentText) => {
  if (commentText.trim()) {
    postsStore.addComment(postId, commentText)
  }
}

const handleDeleteComment = (postId, commentId) => {
  postsStore.deleteComment(postId, commentId)
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Montserrat', sans-serif;
  background: rgba(108, 158, 255, 0.59);
  min-height: 100vh;
}

.app {
  padding: 40px 20px;
}

.container {
  max-width: 1440px;
  margin: 0 auto;
  position: relative;
}

.create-post-section {
  margin-bottom: 40px;
}

.posts-list {
  display: flex;
  flex-direction: column;
  gap: 30px;
}
</style>